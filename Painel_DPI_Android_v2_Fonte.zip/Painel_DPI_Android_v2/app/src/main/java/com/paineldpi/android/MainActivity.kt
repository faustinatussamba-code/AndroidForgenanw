package com.paineldpi.android

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.widget.*
import rikka.shizuku.Shizuku
import java.io.BufferedReader
import java.io.InputStreamReader

class MainActivity : Activity() {
    private val purple = Color.rgb(176, 42, 208)
    private val cardColor = Color.rgb(30, 30, 30)
    private val requestCode = 4201
    private lateinit var status: TextView
    private lateinit var output: TextView
    private lateinit var dpiInput: EditText

    private val permissionListener = Shizuku.OnRequestPermissionResultListener { code, result ->
        if (code == requestCode) {
            status.text = if (result == android.content.pm.PackageManager.PERMISSION_GRANTED)
                "Shizuku autorizado — pronto para aplicar"
            else "Permissão negada. Autorize o app no Shizuku."
            status.setTextColor(if (result == android.content.pm.PackageManager.PERMISSION_GRANTED) Color.GREEN else Color.RED)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Shizuku.addRequestPermissionResultListener(permissionListener)
        makeUi()
        refreshStatus()
    }

    override fun onDestroy() {
        Shizuku.removeRequestPermissionResultListener(permissionListener)
        super.onDestroy()
    }

    private fun makeUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(12), dp(12), dp(16))
            setBackgroundColor(Color.rgb(8, 8, 8))
        }
        val header = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(10), dp(12), dp(10))
            background = rounded(purple, 18)
        }
        header.addView(TextView(this).apply {
            text = "fallresolução"
            textSize = 20f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
        }, LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(TextView(this).apply {
            text = "DPI + TELA"
            textSize = 12f
            setTextColor(Color.WHITE)
            setPadding(dp(9), dp(7), dp(9), dp(7))
            background = rounded(Color.rgb(0, 160, 90), 20)
        })
        root.addView(header)

        status = TextView(this).apply {
            textSize = 13f
            setTextColor(Color.YELLOW)
            setPadding(dp(4), dp(10), dp(4), dp(8))
        }
        root.addView(status)
        root.addView(button("Abrir Shizuku") {
            try { startActivity(Intent("moe.shizuku.manager.intent.action.MAIN")) }
            catch (_: Exception) { startActivity(Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://shizuku.rikka.app/"))) }
        })
        root.addView(button("Solicitar / verificar autorização") { requestPermission() })

        val resolutionPanel = panel()
        resolutionPanel.addView(sectionTitle("RESOLUÇÃO DA TELA"))
        resolutionPanel.addView(note("Aplica o tamanho de tela no Android. Não altera os arquivos do Free Fire."))
        addPreset(resolutionPanel, "RedMagic 10", "1080 × 2340", "wm size 1080x2340")
        addPreset(resolutionPanel, "Realme C75", "1080 × 2400", "wm size 1080x2400")
        addPreset(resolutionPanel, "Galaxy A54", "1216 × 2688", "wm size 1216x2688")
        addPreset(resolutionPanel, "Galaxy S20 Ultra", "1440 × 3088", "wm size 1440x3088")
        addPreset(resolutionPanel, "Galaxy S24 Ultra", "1440 × 3200", "wm size 1440x3200")
        resolutionPanel.addView(button("Restaurar resolução padrão") {
            runCommand("wm size reset", "Resolução padrão restaurada.")
        })
        root.addView(resolutionPanel)

        val dpiPanel = panel()
        dpiPanel.addView(sectionTitle("DPI / DENSIDADE"))
        dpiPanel.addView(note("A DPI é independente da resolução. Valores extremos podem deixar os controles pequenos ou grandes."))
        dpiInput = EditText(this).apply {
            hint = "Digite a DPI, por exemplo 440"
            setHintTextColor(Color.GRAY)
            setTextColor(Color.WHITE)
            textSize = 16f
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            setPadding(dp(12), dp(8), dp(12), dp(8))
            background = rounded(Color.rgb(48, 48, 48), 10)
        }
        dpiPanel.addView(dpiInput, LinearLayout.LayoutParams(-1, -2))
        dpiPanel.addView(button("Aplicar DPI") {
            val value = dpiInput.text.toString().trim().toIntOrNull()
            if (value == null || value !in 100..1000) toast("Digite uma DPI entre 100 e 1000.")
            else runCommand("wm density $value", "DPI aplicada: $value")
        })
        dpiPanel.addView(button("Consultar resolução e DPI atual") {
            runCommand("wm size; wm density", null)
        })
        dpiPanel.addView(button("Restaurar DPI padrão") {
            runCommand("wm density reset", "DPI padrão restaurada.")
        })
        root.addView(dpiPanel)

        val warning = panel()
        warning.addView(sectionTitle("IMPORTANTE"))
        warning.addView(note("A resolução e a DPI afetam o Android inteiro, não apenas o Free Fire. Anote os valores originais antes de testar. Use os botões de restaurar se a tela ficar difícil de usar. O painel não altera FPS nem gráficos internos do jogo."))
        root.addView(warning)

        output = TextView(this).apply {
            text = "Resultado dos comandos aparecerá aqui."
            textSize = 12f
            setTextColor(Color.LTGRAY)
            setPadding(dp(4), dp(10), dp(4), dp(4))
        }
        root.addView(output)
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun addPreset(parent: LinearLayout, name: String, size: String, command: String) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(10), dp(9), dp(10), dp(9))
            background = rounded(Color.rgb(23, 23, 23), 12)
        }
        val texts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        texts.addView(TextView(this).apply {
            text = name
            textSize = 15f
            setTextColor(Color.WHITE)
        })
        texts.addView(TextView(this).apply {
            text = size
            textSize = 12f
            setTextColor(Color.LTGRAY)
        })
        row.addView(texts, LinearLayout.LayoutParams(0, -2, 1f))
        val apply = Button(this).apply {
            text = "Aplicar"
            isAllCaps = false
            textSize = 12f
            setTextColor(Color.WHITE)
            background = rounded(purple, 10)
            setOnClickListener { runCommand(command, "Resolução aplicada: $size") }
        }
        row.addView(apply)
        val lp = LinearLayout.LayoutParams(-1, -2)
        lp.bottomMargin = dp(6)
        parent.addView(row, lp)
    }

    private fun panel() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(12), dp(12), dp(12), dp(12))
        background = rounded(cardColor, 16)
        val lp = LinearLayout.LayoutParams(-1, -2)
        lp.bottomMargin = dp(10)
        layoutParams = lp
    }

    private fun sectionTitle(value: String) = TextView(this).apply {
        text = value
        textSize = 15f
        typeface = Typeface.DEFAULT_BOLD
        setTextColor(Color.WHITE)
        setPadding(0, 0, 0, dp(7))
    }

    private fun note(value: String) = TextView(this).apply {
        text = value
        textSize = 12f
        setTextColor(Color.LTGRAY)
        setPadding(0, 0, 0, dp(8))
    }

    private fun button(value: String, action: () -> Unit) = Button(this).apply {
        text = value
        textSize = 12f
        isAllCaps = false
        setTextColor(Color.WHITE)
        background = rounded(purple, 12)
        setOnClickListener { action() }
        val lp = LinearLayout.LayoutParams(-1, -2)
        lp.topMargin = dp(5)
        layoutParams = lp
    }

    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radius).toFloat()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun refreshStatus() {
        val running = try { Shizuku.pingBinder() } catch (_: Exception) { false }
        status.text = when {
            !running -> "Shizuku não está ativo. Inicie-o primeiro."
            Shizuku.checkSelfPermission() == android.content.pm.PackageManager.PERMISSION_GRANTED -> "Shizuku ativo e autorizado."
            else -> "Shizuku ativo, mas este app precisa de autorização."
        }
    }

    private fun requestPermission() {
        if (!Shizuku.pingBinder()) {
            toast("Inicie o Shizuku e tente novamente.")
            refreshStatus()
        } else if (Shizuku.checkSelfPermission() == android.content.pm.PackageManager.PERMISSION_GRANTED) {
            refreshStatus()
            toast("Permissão já concedida.")
        } else Shizuku.requestPermission(requestCode)
    }

    private fun runCommand(command: String, success: String?) {
        if (!Shizuku.pingBinder()) {
            toast("Shizuku não está ativo.")
            refreshStatus()
            return
        }
        if (Shizuku.checkSelfPermission() != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            toast("Conceda a autorização do Shizuku primeiro.")
            requestPermission()
            return
        }
        Thread {
            try {
                val process = Shizuku.newProcess(arrayOf("sh", "-c", command), null, null)
                val stdout = BufferedReader(InputStreamReader(process.inputStream)).readText()
                val stderr = BufferedReader(InputStreamReader(process.errorStream)).readText()
                val exit = process.waitFor()
                runOnUiThread {
                    output.text = buildString {
                        if (exit == 0 && !success.isNullOrBlank()) append("$success\n")
                        append("Comando: $command\nCódigo: $exit\n")
                        if (stdout.isNotBlank()) append(stdout.trim())
                        if (stderr.isNotBlank()) append("\n${stderr.trim()}")
                        if (stdout.isBlank() && stderr.isBlank() && exit == 0) append("Concluído.")
                    }
                    toast(if (exit == 0) "Comando concluído." else "Comando falhou; confira o resultado.")
                }
            } catch (e: Exception) {
                runOnUiThread { output.text = "Erro: ${e.message ?: "falha ao executar comando"}"; toast("Falha ao executar comando.") }
            }
        }.start()
    }

    private fun toast(value: String) = Toast.makeText(this, value, Toast.LENGTH_LONG).show()
}
