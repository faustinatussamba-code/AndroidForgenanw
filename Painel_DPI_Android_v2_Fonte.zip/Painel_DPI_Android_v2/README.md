# Painel DPI v2 — resolução + DPI

Projeto Android Studio/Kotlin com interface preta e roxa, presets de resolução e ajuste real da densidade do Android usando comandos `wm size` e `wm density` via Shizuku.

## Compilar
1. Extraia o ZIP e abra a pasta no Android Studio.
2. Use JDK 17 e instale Android SDK 35 quando solicitado.
3. Aguarde o Gradle baixar as dependências pela internet.
4. Build > Build APK(s).

## Usar
1. Instale o Shizuku pela fonte oficial: https://shizuku.rikka.app/
2. Inicie o Shizuku pelo método compatível com seu Android (em aparelhos sem root, geralmente Depuração sem fio/ADB).
3. Abra o Painel DPI e conceda a autorização.
4. Antes de alterar, toque em “Consultar resolução e DPI atual” e anote os valores originais.
5. Toque em “Aplicar” no preset de resolução desejado ou insira um valor no campo DPI.
6. Para desfazer: “Restaurar resolução padrão” e “Restaurar DPI padrão”.

## Atenção
- `wm size` e `wm density` alteram a apresentação de todo o Android, não apenas do Free Fire.
- As resoluções mostradas são presets de exemplo; nem todos os aparelhos aceitam todos os valores, e resoluções maiores podem piorar o desempenho ou cortar elementos.
- O app não altera arquivos do Free Fire, não injeta código no jogo e não promete FPS maior.
- É código-fonte, não APK compilado/testado.
